﻿using System.Diagnostics;

namespace Claimit.Test.Chris
{
    /// <summary>
    /// Tests for ICalculator
    /// </summary>
    internal static class CalculatorTests
    {
        /// <summary>
        /// Test parameters 1. We don't include values that will cause an overflow
        /// </summary>
        private static List<int[]> TestParameters1
        {
            get
            {
                return new List<int[]>()
                {
                    new[] { 10, 30 },
                    new[] { 10, -30 },
                    new[] { -10, 30 },
                    new[] { -10, -30 },
                    new[] { 0, 10 },
                    new[] { 0, -10 },
                    new[] { 0, 0 }
                };
            }
        }

        public static void TestAdd(ICalculator calc)
        {
            var parameters = TestParameters1;

            foreach (var values in parameters)
            {
                var expectedAdd = values[0] + values[1];
                Debug.Assert(calc.Add(values[0], values[1]) == expectedAdd);
            }
        }

        public static void TestSubtract(ICalculator calc)
        {
            var parameters = TestParameters1;

            foreach (var values in parameters)
            {
                var expectedSubtract = values[0] - values[1];
                Debug.Assert(calc.Subtract(values[0], values[1]) == expectedSubtract);
            }
        }

        public static void TestMultiply(ICalculator calc)
        {
            var parameters = TestParameters1;

            foreach (var values in parameters)
            {
                var expectedMultiply = values[0] * values[1];
                Debug.Assert(calc.Multiply(values[0], values[1]) == expectedMultiply);
            }
        }
    }
}
