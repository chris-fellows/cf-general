﻿using Claimit.Test.Chris;

public static class Program
{
    public static int Main(string[] args)
    {
        /*
        // Test calculator (Would normally be in a different class library)
        var calc = new Calculator();
        CalculatorTests.TestAdd(calc);
        CalculatorTests.TestSubtract(calc);
        CalculatorTests.TestMultiply(calc);        
        */

        var thinker = new Thinker();

        // Just hard code the parameters. We could read from args if they were set.
        var result = thinker.MagicNumbers(10, 20, 30);
        
        return result;      // Exit code
    } 
}