﻿namespace Claimit.Test.Chris
{
    internal class Thinker
    {
        private readonly ICalculator calc; // Instructions state that instance created in constructor otherwise we'd create it here

        public Thinker()
        {
            calc = new Calculator();
        }

        /// <summary>
        /// Processes the input values
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="c"></param>
        /// <returns>Total value</returns>
        /// <remarks>The spec indicate 3 params otherwise they could have been declared as:
        /// "params int[] values"
        /// </remarks>        
        public int MagicNumbers(int a, int b, int c)
        {
            // Add numbers
            int c1 = 0;
            new[] { a, b, c }.ToList().ForEach(value => c1 = calc.Add(c1, value));           

            Console.WriteLine($"Values added={c1}");

            // Subtract numbers: subtract a from (b minus c)
            var c2 = calc.Subtract(calc.Subtract(b, c), a);

            Console.WriteLine($"Values subtracted={c2}");

            // Multiply values
            var c3 = calc.Multiply(calc.Multiply(a, b), c);

            Console.WriteLine($"Values multiplied={c3}");

            return c3;
        }        
    }
}
