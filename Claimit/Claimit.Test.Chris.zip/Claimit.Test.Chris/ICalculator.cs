﻿namespace Claimit.Test.Chris
{
    /// <summary>
    /// Calculator interface
    /// </summary>
    internal interface ICalculator
    {   
        /// <summary>
        /// Adds values
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <returns></returns>
        int Add(int value1, int value2);
     
        /// <summary>
        /// Subtracts <paramref name="value2"/> from <paramref name="value1"/>
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <returns></returns>
        int Subtract(int value1, int value2);

        /// <summary>
        /// Multiplies values
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <returns></returns>
        int Multiply(int value1, int value2);
    }
}
