﻿namespace Claimit.Test.Chris
{
    /// <summary>
    /// Calculator implementation
    /// </summary>
    internal class Calculator : ICalculator
    {
        public int Add(int value1, int value2)
        {
            return value1 + value2;
        }

        public int Subtract(int value1, int value2)
        {
            return value1 - value2;
        }
        
        public int Multiply(int value1, int value2)
        {
            /* INSTRUCTIONS:
            Extend ICalculator with a new method called Multiply returning an int and taking two int parameters. 
            Implement Multiply in the Calculator class by repeatedly calling the Add method.
            Make MagicNumbers use ICalculator.Multiple() to print a* b*c on the screen.
            */
            
            // Multiply by repeatedly calling the Add method as instructed. We could otherwise just return value1 * value2           
            // Calling Add repeatledly isn't very efficient
            int total = 0;
            for (var index = 1; index <= Math.Abs(value1); index++)
            {
                total = Add(total, Math.Abs(value2));
            }

            // Set correct sign value
            var countNegative = (value1 < 0 ? 1 : 0) + (value2 < 0 ? 1 : 0);
            if (countNegative == 1) total = -total;            

            return total;           // return value1 * value2;            
        }
    }
}
