﻿using CFSnap.Enum;

namespace CFSnap.Interfaces
{
    /// <summary>
    /// Game output
    /// </summary>    
    internal interface IGameOutput
    {
        /// <summary>
        /// Logs message
        /// </summary>
        /// <param name="logType"></param>
        /// <param name="message"></param>
        /// <param name="parameters">Parameters related to log type. E.g. Player</param>
        void Log(LogTypes logType, string message, Dictionary<string, object> parameters);
    }
}
