﻿using CFSnap.Models;

namespace CFSnap.Interfaces
{
    /// <summary>
    /// Service for CardType instances
    /// </summary>
    internal interface ICardTypeService
    {
        List<CardType> GetAll();
    }
}
