﻿using CFSnap.Models;

namespace CFSnap.Interfaces
{
    /// <summary>
    /// Service for named CardStack instances
    /// </summary>   
    internal interface ICardStackService
    {
        /// <summary>
        /// Gets CardStack by card type. E.g. Standard card stack (Clubs, hearts etc)
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        CardStack GetByCardType(string name);
    }
}
