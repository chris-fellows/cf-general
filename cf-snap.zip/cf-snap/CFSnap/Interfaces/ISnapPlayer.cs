﻿using CFSnap.Enum;
using CFSnap.Models;

namespace CFSnap.Interfaces
{
    /// <summary>
    /// Interface for snap player
    /// </summary>
    internal interface ISnapPlayer
    {
        Player Player { get; }

        /// <summary>
        /// Notification that player can call snap. Typically not available until cards have been dealt.
        /// </summary>
        /// <param name="enable"></param>
        void NotifyEnableCallSnap(bool enable);

        /// <summary>
        /// Notification that player is enabled to take turn and other players cannot
        /// </summary>
        /// <param name="player"></param>
        void NotifyTurnSourceEnabled(Player player);

        /// <summary>
        /// Notification that player has turned source card. Players may subsequently call snap if two cards match
        /// </summary>
        /// <param name="player"></param>
        void NotifyTurnedSourceCard(Player player);

        /// <summary>
        /// Notification that game state has changed. E.g. Game over
        /// </summary>
        /// <param name="gameState"></param>
        void NotifyGameState(SnapGameStates gameState);
    }
}
