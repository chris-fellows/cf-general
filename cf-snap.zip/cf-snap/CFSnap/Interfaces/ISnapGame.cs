﻿using CFSnap.Enum;
using CFSnap.Models;

namespace CFSnap.Interfaces
{
    /// <summary>
    /// Implements snap game. We only implement the methods that ISnapPlayer requires.
    /// </summary>
    internal interface ISnapGame
    {
        /// <summary>
        /// Turns source card for player
        /// </summary>
        /// <param name="player"></param>
        void TurnSourceCard(Player player);

        /// <summary>
        /// Calls snap for player
        /// </summary>
        /// <param name="player"></param>
        /// <returns></returns>
        bool CallSnap(Player player);

        /// <summary>
        /// Game state
        /// </summary>
        public SnapGameStates GameState { get; }
    }
}
