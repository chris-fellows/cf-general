﻿namespace CFSnap.Interfaces
{
    /// <summary>
    /// Interface for running game
    /// </summary>
    /// <typeparam name="TOptionsType">Simulator options</typeparam>
    /// <remarks>Would be used if we expand this mechanism to simulate other games</remarks>
    internal interface IGameRunner<TOptionsType>
    {
        /// <summary>
        /// Runs game asynchronously
        /// </summary>
        /// <param name="options"></param>
        /// <param name="cancellationToken"></param>
        Task RunAsync(TOptionsType options, CancellationToken cancellationToken);
    }
}
