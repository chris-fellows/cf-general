﻿using CFSnap.Enum;
using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{
    /// <summary>
    /// Snap game interactive example. Uses interactive players. Each ISnapPlayer instance is linked to a real world player
    /// (<see cref="InteractiveSnapPlayer"/>)
    /// </summary>
    internal class InteractiveSnapRunner : IGameRunner<SnapOptions>
    {
        private readonly IGameOutput _output;

        public InteractiveSnapRunner(IGameOutput output)
        {
            _output = output;
        }

        /// <summary>
        /// Runs Snap game asynchronously.
        /// </summary>
        /// <param name="options">Snap simulator options</param>        
        /// <param name="cancellationToken">Cancellation token</param>
        public Task RunAsync(SnapOptions options, CancellationToken cancellationToken)
        {
            return Task.Factory.StartNew(() =>
             {
                 _output.Log(LogTypes.GameStarted, "Game started", new());

                 // Run game

                 _output.Log(LogTypes.GameOver, "Game over", new());
             });
        }       
    }
}
