﻿using CFSnap.Enum;
using CFSnap.Exceptions;
using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{
    /// <summary>
    /// Snap game running in local process.
    /// 
    /// Notes:
    /// - GameState property will be checked to prevent the game being corrupted.
    /// </summary>
    internal class LocalSnapGame : ISnapGame
    {
        /// <summary>
        /// Muex for serializing access to game to prevent state getting corrupted
        /// </summary>
        private Mutex _mutex = new Mutex();

        private IGameOutput _snapOutput;
        private SnapGameStates _gameState;
        private SnapOptions _snapOptions;
        private List<ISnapPlayer> _players = new();        
        private CardStack _destinationCardStack = new CardStack();

        public LocalSnapGame(SnapOptions snapOptions, IGameOutput snapOutput)
        {
            _snapOptions = snapOptions;
            _snapOutput = snapOutput;
        }

        public List<ISnapPlayer> SnapPlayers => _players;

        /// <summary>
        /// Clears game (Removes players, resets to initial state)
        /// </summary>
        public void Clear()
        {
            
        }

        /// <summary>
        /// Adds player to game
        /// </summary>
        /// <param name="player"></param>
        public void AddPlayer(ISnapPlayer snapPlayer)
        {

        }

        /// <summary>
        /// Deals source cards to each player (Player.SourceCardsStack) at start of game. Shuffles if required
        /// </summary>
        /// <param name="cardStack"></param>
        public void DealSourceCards()
        {
            _snapOptions.SourceCardStack.Shuffle();
        }

        /// <summary>
        /// Destination card stack for turned up cards. The card from the player's source stack is turned over and moved to
        /// this stack.
        /// </summary>
        public CardStack DestinationCardStack
        {
            get { return _destinationCardStack; }
        }

        /// <summary>
        /// Notifies all players whether player can call snap. Calls ISnapPlayer.NotifyEnableCallSnap
        /// </summary>
        /// <param name="enable"></param>
        public void NotifyCanCallSnap(bool enable)
        {
            //_players.ForEach(player => player.NotifyEnableCallSnap(enable));
        }

        /// <summary>
        /// Notifies all players which player can turn over their source card. Calls ISnapPlayer.NotifyTurnSourceCardEnabled
        /// </summary>
        /// <param name="player"></param>
        public void NotifyCanTurnSourceCard(Player player)
        {
            //_players.ForEach(player => player.NotifyTurnSourceEnabled(player.Player));
        }

        /// <summary>
        /// Notifies all players that the player turned over a source card. Calls ISnapPlayer.NotifyTurnedSourceCard
        /// 
        /// This may result in a subsequent call to <see cref="CallSnap"/>
        /// </summary>
        /// <param name="player"></param>
        public void NotifyTurnedSourceCard(Player player)
        {
            //_players.ForEach(player => player.NotifyTurnedSourceCard(player.Player));
        }

        /// <summary>
        /// Notifies all players of game state. Calls ISnapPlayer.NotifyGameState
        /// </summary>        
        public void NotifyGameState()
        {
            //_players.ForEach(player => player.NotifyGameState(_gameState));
        }

        /// <summary>
        /// Handles player turning over card on source stack:
        /// 1) Moves card from player source stack (Player.SourceCardStack) to destination stack (DestinationCardStack)
        /// 2) Notifies all players that a player turned over a card (<see cref="NotifyTurnedSourceCard"/>)
        /// 3) If snap needs to be called then wait (<see cref="WaitForCallSnap"/>)
        /// 4) Notifies next player that it's their turn (<see cref="NotifyCanTurnSourceCard"/>)
        /// 
        /// Access to this method and CallSnap would be serialized to handle simultaneous calls from multiple players.
        /// 
        /// Throws <see cref="TurnCardNotAllowedException"/> if player not allowed to turn source card.
        /// </summary>
        /// <param name="player"></param>        
        public void TurnSourceCard(Player player)
        {

        }

        /// <summary>
        /// Handles player calling snap:
        /// 1) Checks that last 2 cards on DestinationCardStack match using SnapOptions.CardType.IsCardMatchedFunction.
        /// 2) If 2 cards match then moves won cards to player's card stack (<see cref="MoveCardsWon"/>)
        /// 3) Checks if game over (<see cref="CheckIfGameOver"/>) and sets GameState property if necessary and then calls
        ///    <see cref="NotifyGameState"/>
        /// 
        /// Access to this method and TurnSourceCard would be serialized to handle simultanous calls from multiple players.
        /// If the call is rejected then the method returns false.
        /// 
        /// Throws <see cref="CallSnapNotAllowedException"/> if player not allowed to call snap.
        /// </summary>
        /// <param name="player"></param>
        /// <returns>Whether player won the cards</returns>
        public bool CallSnap(Player player)
        {
            return true;
        }   

        /// <summary>
        /// Whether game needs to wait for call snap because 2 matching cards are visible
        /// </summary>
        private bool IsNeedToWaitForCallSnap
        {
            get { return false; }
        }

        /// <summary>
        /// Waits for snap to be called
        /// </summary>
        private void WaitForCallSnap()
        {

        }
        
        /// <summary>
        /// Moves won cards to player's card stack
        /// </summary>
        /// <param name="cardStacksWon"></param>
        /// <param name="destinationCardStack"></param>
        private void MoveCardsWon(List<CardStack> cardStacksWon, Player player)
        {
            
        }

        /// <summary>
        /// Checks if the game is over and sets GameState if it is
        /// </summary>
        private void CheckIfGameOver()
        {
            
        }

        /// <summary>
        /// Winning player
        /// </summary>
        public ISnapPlayer WinningPlayer => null;

        /// <summary>
        /// Game state
        /// </summary>
        public SnapGameStates GameState => _gameState;
    }
}
