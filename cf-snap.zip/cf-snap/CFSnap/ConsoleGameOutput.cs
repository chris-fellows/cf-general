﻿using CFSnap.Enum;
using CFSnap.Interfaces;

namespace CFSnap
{
    /// <summary>
    /// Game output to console
    /// </summary>
    internal class ConsoleGameOutput : IGameOutput
    {        
        public void Log(LogTypes logType, string message, Dictionary<string, object> parameters)
        {
            
        }
    }
}
