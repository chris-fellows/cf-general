﻿namespace CFSnap.Exceptions
{
    /// <summary>
    /// Exception for not allowed to turn card
    /// </summary>
    internal class TurnCardNotAllowedException : GameException
    {
    }
}
