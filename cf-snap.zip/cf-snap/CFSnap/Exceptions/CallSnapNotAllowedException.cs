﻿namespace CFSnap.Exceptions
{
    /// <summary>
    /// Exception for not allowed to call snap
    /// </summary>
    internal class CallSnapNotAllowedException : GameException
    {
    }
}
