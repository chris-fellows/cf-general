﻿using System.Globalization;

namespace CFSnap.Exceptions
{
    /// <summary>
    /// General game exception
    /// </summary>
    internal class GameException : Exception
    {
        public GameException()
        {
        }

        public GameException(string message) : base(message)
        {

        }

        public GameException(string message, Exception innerException) : base(message, innerException)
        {
        }


        public GameException(string message, params object[] args)
            : base(string.Format(CultureInfo.CurrentCulture, message, args))
        {
        }
    }
}
