﻿using CFSnap.Enum;
using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{
    /// <summary>
    /// Snap game simulator. Uses simulated players that behave randomly.
    /// </summary>
    internal class SimulatorSnapRunner : IGameRunner<SnapOptions>
    {
        private readonly IGameOutput _output;                

        public SimulatorSnapRunner(IGameOutput output)
        {
            _output = output;
        }

        /// <summary>
        /// Runs Snap game asynchronously:
        /// 1) Creates SnapGame.
        /// 2) Creates players.
        /// 3) Deals source cards to all players.
        /// 4) Starts thread for each player.
        /// 5) Notifies all players that they can call snap.        
        /// 6) Notifies all players that first player can turn over their card.
        /// 7) Loops until SnapGame.State = GameOver and handles interaction from ISnapPlayer instances.
        /// 
        /// If cancellation requested then method aborts.
        /// </summary>
        /// <param name="options">Snap simulator options</param>        
        /// <param name="cancellationToken">Cancellation token</param>
        public Task RunAsync(SnapOptions options, CancellationToken cancellationToken)
        {
            return Task.Factory.StartNew(() =>
            {
                _output.Log(LogTypes.GameStarted, "Game started", new());

                // Create game
                var snapGame = new LocalSnapGame(options, _output);

                // Create player simulators
                var snapPlayers = CreateSnapPlayers(cancellationToken, snapGame, options.PlayerCount);

                // Add players to game
                snapPlayers.ForEach(sp => snapGame.AddPlayer(sp));

                // Deal cards
                DealSourceCards(snapGame);

                // Notify players that they can call snap
                NotifyEnableCallSnap(snapGame);

                // Notify players which player can turn over card (First player)
                NotifyEnableTurnSourceCard(snapGame, snapGame.SnapPlayers.First(p => p.Player.Sequence == options.FirstPlayerSequence));

                // Loop here and handle player interaction until game is over or cancelled
                while (snapGame.GameState != SnapGameStates.GameOver &&
                    !cancellationToken.IsCancellationRequested)
                {
                    System.Threading.Thread.Sleep(500);
                }

                _output.Log(LogTypes.GameOver, "Game over", new());
            });
        }

        /// <summary>
        /// Creates N player simulators and players
        /// </summary>
        /// <param name="playerCount"></param>
        private List<ISnapPlayer> CreateSnapPlayers(CancellationToken cancellationToken, LocalSnapGame snapGame, int playerCount)
        {
            var snapPlayers = new List<ISnapPlayer>();
            for (int index = 0; index < playerCount; index++)
            {
                var player = new Player() { Sequence = index, SourceCardStack = new CardStack(), Name = $"Player {index + 1}" };
                var snapPlayer = new SimulatorSnapPlayer(cancellationToken, player, snapGame);
                snapPlayers.Add(snapPlayer);
            }

            return snapPlayers;
        }

        /// <summary>
        /// Deals source cards to players before players start turning over cards
        /// </summary>
        /// <param name="game"></param>
        private void DealSourceCards(LocalSnapGame snapGame)
        {
            snapGame.DealSourceCards();
        }

        /// <summary>
        /// Notifies all players that they can call snap
        /// </summary>
        /// <param name="snapGame"></param>
        /// <param name="snapPlayer"></param>
        private void NotifyEnableCallSnap(LocalSnapGame snapGame)
        {
            snapGame.NotifyCanCallSnap(true);
        }

        /// <summary>
        /// Notifies all players which player can turn over their source card
        /// </summary>
        /// <param name="snapGame"></param>
        /// <param name="player"></param>
        private void NotifyEnableTurnSourceCard(LocalSnapGame snapGame, ISnapPlayer snapPlayer)
        {
            snapGame.NotifyCanTurnSourceCard(snapPlayer.Player);
        }       
    }
}
