﻿using CFSnap.Enum;
using CFSnap.Interfaces;

namespace CFSnap
{
    /// <summary>
    /// Game output to memory. This can be used for testing where output is saved in memory and can be analysed
    /// during the test
    /// </summary>   
    internal class MemoryGameOutput : IGameOutput
    {
        private readonly Action<LogTypes, string, Dictionary<string, object>> _logAction;

        /// <summary>
        /// Contructor that accepts method to call for accumulating output
        /// </summary>
        /// <param name="logAction"></param>
        public MemoryGameOutput(Action<LogTypes, string, Dictionary<string, object>> logAction)
        {
            _logAction = logAction;
        }

        public void Log(LogTypes logType, string message, Dictionary<string, object> parameters)
        {
            //_logAction(logType, message, parameters);
        }
    }
}
