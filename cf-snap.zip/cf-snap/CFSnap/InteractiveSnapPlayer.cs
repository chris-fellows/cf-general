﻿using CFSnap.Enum;
using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{
    /// <summary>
    /// Snap player user control example. THIS CLASS WOULD REALLY BE A USER CONTROL. I've created it just to
    /// demonstrate that there can be different implementations of ISnapPlayer. This class would be used in
    /// conjunction with <see cref="InteractiveSnapRunner"/>
    /// 
    /// An example use is a WinForms/WPF app where there's a user control for each player with buttons to turn
    /// over the source card or call snap. This isn't very practical in the real world because you can't have
    /// multiple players sitting in front of the same app with their own mouse. It's really just for a single
    /// user who is testing the game.
    /// </summary>
    internal class InteractiveSnapPlayer : ISnapPlayer    // THIS CLASS WOULD REALLY BE A USER CONTROL
    {
        private readonly Player _player;

        public InteractiveSnapPlayer(Player player)
        {
            _player = player;
        }

        public Player Player => _player;

        public void NotifyEnableCallSnap(bool enable)
        {
            // Enable or disable button to call snap
        }

        public void NotifyTurnSourceEnabled(Player player)
        {
            // Enable or disable button to turns source card
        }

        public void NotifyTurnedSourceCard(Player player)
        {
            // Don't need to take action as "Call Snap" button would be enabled all of the time
        }

        public void NotifyGameState(SnapGameStates gameState)
        {

        }
    }
}
