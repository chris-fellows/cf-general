﻿using CFSnap.Constants;
using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{
    /// <summary>
    /// Gets CardType instances from memory. Typically this would come from a database
    /// </summary>
    internal class MemoryCardTypeService : ICardTypeService
    {
        public List<CardType> GetAll()
        {
            var cardTypes = new List<CardType>();

            cardTypes.Add(new CardType()
            {
                Name = CardTypeNames.Standard,
                IsCardMatchedFunction = (Card card1, Card card2) =>
                {
                    return ((StandardCard)card1).Number == ((StandardCard)card2).Number;
                }
            });

            cardTypes.Add(new CardType()
            {
                Name = CardTypeNames.Animal,
                IsCardMatchedFunction = (Card card1, Card card2) =>
                {
                    return ((AnimalCard)card1).Name == ((AnimalCard)card2).Name;
                }
            });

            return cardTypes;
        }
    }
}
