﻿using CFSnap.Enum;
using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{   
    /// <summary>
    /// Snap player simulator. The instance operates automatically. It runs a separate thread which handles notifications
    /// and interacts with the game. E.g. If notification that user can turn over source card then RunThread turns over card.
    /// </summary>
    internal class SimulatorSnapPlayer : ISnapPlayer
    {
        private Thread _thread;
        private readonly Player _player;
        private readonly ISnapGame _snapGame;
        private CancellationToken _cancellationToken;

        public SimulatorSnapPlayer(CancellationToken cancellationToken, Player player, ISnapGame snapGame)
        {
            _cancellationToken = cancellationToken;
            _player = player;
            _snapGame = snapGame;
        }

        public Player Player => _player;
                
        public void NotifyEnableCallSnap(bool enable)
        {
            // RunThread would check if this was called
        }

        public void NotifyTurnSourceEnabled(Player player)
        {
            // RunThread would check if this was called
        }

        public void NotifyTurnedSourceCard(Player player)
        {
            // RunThread would check if this was called
        }

        public void NotifyGameState(SnapGameStates gameState)
        {
            // RunThread would check if this was called
        }

        /// <summary>
        /// Runs thread until SnapGame.Status = GameOver or thread cancelled:
        /// 1) Pauses if no action is required.
        /// 2) Calls <see cref="TurnSourceCard"/> if NotifyTurnSourceEnabled event indicates it can be
        /// called.
        /// 3) Calls <see cref="CallSnap"/> if NotifyTurnedSourceCard indicates that it can be called.        
        /// </summary>
        public void RunThread()
        {
         
        }

        /// <summary>
        /// Turns source card. Called from <see cref="RunThread"/>
        /// </summary>
        private void TurnSourceCard()
        {
            _snapGame.TurnSourceCard(_player);
        }

        /// <summary>
        /// Calls snap. Called from <see cref="RunThread"/>
        /// </summary>
        private void CallSnap()
        {
            _snapGame.CallSnap(_player);
        }
    }
}
