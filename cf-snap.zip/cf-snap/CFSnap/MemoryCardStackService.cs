﻿using CFSnap.Interfaces;
using CFSnap.Models;

namespace CFSnap
{
    /// <summary>
    /// Gets CardStack instances from memory. Typically this would come from a database.
    /// </summary>
    internal class MemoryCardStackService : ICardStackService
    {
        /// <summary>
        /// Gets named CardStack instance. E.g. Standard card stack.
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public CardStack GetByCardType(string name)
        {
            return GetStandardCardStack();
        }

        /// <summary>
        /// Returns standard card stack. Contains StandardCard instanes
        /// </summary>
        /// <returns></returns>
        private CardStack GetStandardCardStack()
        {
            var cardStack = new CardStack();
            
            return cardStack;
        }
    }
}
