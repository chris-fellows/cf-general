﻿using CFSnap;
using CFSnap.Constants;
using CFSnap.Interfaces;
using CFSnap.Models;

// Get card stack service to get the source cards to use
ICardStackService cardStackService = new MemoryCardStackService();

// Get card type Standard
var cardTypeName = CardTypeNames.Standard;
//var cardTypeNames = CardTypeNames.Animal;
ICardTypeService cardTypeService = new MemoryCardTypeService();
var cardType = cardTypeService.GetAll().First(ct => ct.Name == cardTypeName);

// Set options. Would typically get these from a UI or config file
var snapOptions = new SnapOptions()
{
    CardType = cardType,
    DealSameNumberOfCardsPerPlayer = true,
    FirstPlayerSequence = 0,   // First player
    PlayerCount = 5,
    ShuffleCardsBeforeDealing = true,   // Can be set to false for testing where we want cards dealt in predictable order
    SourceCardStack = cardStackService.GetByCardType(cardType.Name),  // For testing then we can see a subset of cards
    //SerializationDelayForTesting = TimeSpan.FromSeconds(5)    // For testing
};

// Set output
IGameOutput gameOutput = new ConsoleGameOutput();
//var logs = new List<Tuple<LogTypes, string, Dictionary<string, object>>>();
//IGameOutput gameOutput = new MemoryGameOutput((LogTypes logType, string message, Dictionary<string, object> parameters) =>
//{
//    logs.Add(new Tuple<LogTypes, string, Dictionary<string, object>>(logType, message, parameters));
//});

// Create token source for cancellation
CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();

// Run Snap game simulator
IGameRunner<SnapOptions> snapRunner = new SimulatorSnapRunner(gameOutput);
//IGameRunner<SnapOptions> snapRunner2 = new SnapRunnerInteractive(gameOutput);
var gameTask = snapRunner.RunAsync(snapOptions, cancellationTokenSource.Token);
gameTask.Wait();
