﻿namespace CFSnap.Constants
{
    /// <summary>
    /// Card type names
    /// </summary>
    internal class CardTypeNames
    {
        public static string Standard = "Standard";
        public static string Animal = "Animal";     // Example
    }
}
