﻿namespace CFSnap.Enum
{
    /// <summary>
    /// Card suits
    /// </summary>
    internal enum CardSuits
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
