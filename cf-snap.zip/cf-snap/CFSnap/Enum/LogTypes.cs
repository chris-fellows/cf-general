﻿namespace CFSnap.Enum
{
    /// <summary>
    /// Log actions
    /// </summary>
    /// <remarks>This list can be extended if necessary</remarks>
    internal enum LogTypes
    {
        Unknown, 
        Error,
        GameOver,
        GameStarted,
        GameStateChanged,
        SnapCalled,
        SourceCardTurned
    }
}
