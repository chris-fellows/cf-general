﻿namespace CFSnap.Enum
{
    /// <summary>
    /// Snap game states.
    /// </summary>
    internal enum SnapGameStates
    {
        /// <summary>
        /// First state. Not ready to deal cards yet
        /// </summary>
        Initial,

        /// <summary>
        /// Dealing cards to all players. If cards are dealt out quickly then this state only exists for fractions
        /// of a second.
        /// </summary>
        DealingCards,

        /// <summary>
        /// Game active. Players turning cards
        /// </summary>
        Active,

        /// <summary>
        /// Game over, winner decided
        /// </summary>
        GameOver        
    }
}
