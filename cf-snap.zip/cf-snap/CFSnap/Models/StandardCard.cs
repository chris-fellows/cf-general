﻿using CFSnap.Enum;

namespace CFSnap.Models
{
    /// <summary>
    /// Standard card (Clubs, diamonds, hearts, spades)
    /// </summary>
    internal class StandardCard : Card    
    { 
        /// <summary>
        /// Card suit
        /// </summary>
        public CardSuits Suit { get; set; }

        /// <summary>
        /// Card number (1-13)
        /// </summary>
        public int Number { get; set; }
    }
}
