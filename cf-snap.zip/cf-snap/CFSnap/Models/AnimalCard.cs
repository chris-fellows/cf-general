﻿namespace CFSnap.Models
{
    /// <summary>
    /// Animal card (Example card)
    /// </summary>
    internal class AnimalCard : Card
    {
    }
}
