﻿namespace CFSnap.Models
{    
    /// <summary>
    /// Snap player
    /// </summary>
    internal class Player
    {        
        /// <summary>
        /// Player name
        /// </summary>
        public string Name { get; set; } = String.Empty;

        /// <summary>
        /// Sequence in which player turns over cards (0=First player)
        /// </summary>
        public int Sequence { get; set; }

        /// <summary>
        /// Source cards that player turns over
        /// </summary>
        public CardStack SourceCardStack { get; set; }      
    }
}
