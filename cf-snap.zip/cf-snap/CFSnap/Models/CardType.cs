﻿namespace CFSnap.Models
{
    /// <summary>
    /// Card type. E.g. Standard.
    /// </summary>
    internal class CardType
    {
        /// <summary>
        /// Card type name. E.g. "Standard", "Animal"
        /// </summary>
        public string Name { get; set; } = String.Empty;

        /// <summary>
        /// Function to determine if cards are matched
        /// </summary>
        public Func<Card, Card, bool> IsCardMatchedFunction { get; set; }
    }
}
