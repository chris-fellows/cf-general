﻿namespace CFSnap.Models
{
    /// <summary>
    /// Playing card
    /// </summary>
    internal abstract class Card
    {
        /// <summary>
        /// Card name. E.g. "6 hearts", "Horse"
        /// </summary>
        public string Name { get; set; } = String.Empty;
    }
}
