﻿namespace CFSnap.Models
{
    /// <summary>
    /// Snap game options
    /// </summary>
    internal class SnapOptions
    {
        /// <summary>
        /// Number of players
        /// </summary>
        public int PlayerCount { get; set; }

        /// <summary>
        /// Source cards to use. E.g. Standard
        /// </summary>
        public CardStack SourceCardStack { get; set; }

        /// <summary>
        /// Whether to shuffle cards before dealing (For testing if we want to disable shuffling so that cards are
        /// allocated to players in predicatable order)
        /// </summary>
        public bool ShuffleCardsBeforeDealing { get; set; } = true;

        /// <summary>
        /// Whether to deal same number of cards to each player and discard extra cards. If false then all cards are
        /// dealt to players, even if some players have more cards.
        /// </summary>
        public bool DealSameNumberOfCardsPerPlayer { get; set; } = true;

        /// <summary>
        /// First player to turn over a card when game starts
        /// </summary>
        public int FirstPlayerSequence { get; set; } = 0;

        /// <summary>
        /// Card type. E.g. Standard
        /// </summary>
        public CardType CardType { get; set; }

        /// <summary>
        /// When serializing access to game then the delay to maintain the lock in order to cause multiple players
        /// to simultaneously try and turn over a card or call snap (For testing)
        /// </summary>
        public TimeSpan SerializationDelayForTesting { get; set; } = TimeSpan.Zero;
    }
}
