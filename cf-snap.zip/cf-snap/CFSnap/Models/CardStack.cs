﻿using System.Collections;

namespace CFSnap.Models
{
    /// <summary>
    /// Playing card stack
    /// </summary>
    internal class CardStack : IEnumerable
    {
        private List<Card> _cards = new List<Card>();

        /// <summary>
        /// Clears cards
        /// </summary>
        public void Clear()
        {
          
        }

        public IEnumerator GetEnumerator()
        {                        
            foreach (Card card in _cards)
            {                
                yield return card;
            }            
        }

        /// <summary>
        /// Adds card to stack
        /// </summary>
        /// <param name="card"></param>
        public void Add(Card card)
        {
            _cards.Add(card);
        }

        /// <summary>
        /// Removes card
        /// </summary>
        /// <param name="card"></param>
        public void Remove(Card card)
        {
            _cards.Remove(card);
        }

        /// <summary>
        /// Shuffles cards randomly
        /// </summary>
        public void Shuffle()
        {
           
        }       
    }
}
